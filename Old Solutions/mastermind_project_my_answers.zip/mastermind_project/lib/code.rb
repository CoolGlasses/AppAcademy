require "byebug"

class Code
  POSSIBLE_PEGS = {
    "R" => :red,
    "G" => :green,
    "B" => :blue,
    "Y" => :yellow
  }

  def self.valid_pegs?(array)
    array.each do |char|
      if !POSSIBLE_PEGS.has_key?(char.upcase)
         return false 
      end
    end 
  

    return true
  end 

  def self.random(length)
    random_pegs = []
    length.times { random_pegs << POSSIBLE_PEGS.keys.sample }
    Code.new(random_pegs)
  end

  def self.from_string(string_of_pegs)
    array = string_of_pegs.split("")
    Code.new(array)
  end

  def initialize(pegs_array)
    @pegs = []
    if Code.valid_pegs?(pegs_array)
        @pegs = pegs_array
    else  
      raise error
    end 

    @pegs.each do |peg|
      if peg == peg.downcase
         peg.upcase!
      end 
    end 

  end 
   

  def pegs
    @pegs 
  end 

  def [](index)
    @pegs[index]
  end

  def length
    @pegs.length
  end 

  def num_exact_matches(new_instance)
    count = 0


    (0...new_instance.length).each do |i|
      if new_instance[i] == self[i]
        count += 1
      end 
    end 

    return count 
  end

  def num_near_matches(new_instance)
    count = 0

    
    (0...new_instance.length).each do |i|
      if new_instance[i] != self[i] && self.pegs.include?(new_instance[i])
        count += 1
      end 
    end 

    return count 
  end

  def ==(arg)
    if self.pegs == arg.pegs
      return true 
    else  
      return false 
    end 
  end  

end