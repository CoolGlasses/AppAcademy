# Run `bundle exec rspec` and satisy the specs.
# You should implement your methods in this file.
# Feel free to use the debugger when you get stuck.

require "byebug"

###first problem###
def largest_prime_factor(num)
factors = []

    if is_prime?(num)
        return num 
    end 

    (2...num).each do |factor|
        if num % factor == 0 && is_prime?(factor)
            factors << factor
        end 
    end

    return factors[-1]

end

def is_prime?(num)

(2...num).each do |n|
    if num % n == 0
        return false 
    end 
end 

    return true


end

###second problem###
def unique_chars?(string)

    string.each_char.with_index do |letter1, i|
        string.each_char.with_index do |letter2, k|
            if i < k && letter1 == letter2
                return false 
            end 
        end 
    end 

    return true

end

###third problem###
def dupe_indices(array)

hash = {}
hash = Hash.new(0)

array.each_with_index do |ele1, i|
    if hash.has_key?(ele1)
        next 
    end 
    tempArray = []

    array.each_with_index do |ele2, k|
        if i < k && ele1 == ele2 && tempArray.include?(i)
            tempArray << k
        elsif i < k && ele1 == ele2 
            tempArray << i
            tempArray << k
        end 
    end 
    if tempArray.length > 1
        hash[ele1] = tempArray 
    end
end 

return hash

end

###fourth problem###

def ana_array(array1, array2)

array1.each do |ele1|
  array2.each do |ele2|
        if !array1.include?(ele2) || !array2.include?(ele1)
            return false
        end
    end  
end 

        return true  

end