require "byebug"

class Bootcamp
    def initialize(name, slogan, student_capacity)
        @name = name
        @slogan = slogan 
        @student_capacity = student_capacity
        @teachers = []
        @students = []
        @grades = Hash.new { |hash, k| hash[k] = [] }
    end 

    def name
        @name 
    end 

    def slogan 
        @slogan 
    end 

    def teachers
        @teachers 
    end 

    def students 
        @students
    end

    def hire(string)
        @teachers << string 
    end 

    def enroll(string)
        if @students.length < @student_capacity
            @students << string 
            return true
        else  
            return false
        end
    end 

    def enrolled?(string)
        if @students.include?(string)
            return true
        else  
            return false 
        end 
    end 

    def student_to_teacher_ratio
        ratio = 0

        ratio = @students.length / @teachers.length  

        ratio = ratio.round
    end 

    def add_grade(string, grade)
        if enrolled?(string)
            @grades[string] << grade
            return true
        else  
            return false 
        end 
    end 

    def num_grades(string)
        return @grades[string].length
    end

    def average_grade(string)
        average_grade = 0
        if @grades[string] == [] || !enrolled?(string)
            return nil
        else  
            average_grade = @grades[string].sum / @grades[string].length
            average_grade = average_grade.round 
            return average_grade 
        end 
    end 

  
end
