require_relative "room"

class Hotel
    def initialize(string, rooms_hash)
        @name = string 
        @rooms = {}
            rooms_hash.each do |key, val|
                @rooms[key] = Room.new(val)
            end 
    end

    def name
        name = @name
        array = name.split(" ")
        capitalized_name = array.each { |word| word.capitalize! }
        return capitalized_name.join(" ")
    end 

    def rooms 
        @rooms 
    end 

    def room_exists?(room_name)
        if @rooms.has_key?(room_name)
            return true
        else  
            return false
        end 
    end 

    def check_in(person, room_name)
        if !room_exists?(room_name)
            p "sorry, room does not exist"
        elsif  @rooms[room_name].full?
                p "sorry, room is full"
        else  
            @rooms[room_name].add_occupant(person)
            p 'check in successful'          
        end 
    end 

    def has_vacancy?
        @rooms.each do |room_name, occupancy|
            if !@rooms[room_name].full?
                return true 
            end 
        end 
        return false
    end 

    def list_rooms
        @rooms.each do |room_name, room|
          puts "#{room_name} : #{room.available_space}"
        end 
    end 

end
