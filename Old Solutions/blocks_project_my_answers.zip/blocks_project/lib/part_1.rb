def select_even_nums(array)

evens = []

evens = array.select(&:even?)

return evens 

end

def reject_puppies(array_of_hashes)

old_dogs = []

old_dogs = array_of_hashes.reject { |hash| hash["age"] <= 2 }

return old_dogs 

end

def count_positive_subarrays(array)

count = 0

count = array.count do |subArray|
    if subArray.length < 2 && subArray[0] > 0
        count += 1
    elsif  subArray.sum > 0
        count += 1
    end 
end 


return count

end


#####################################


def aba_translate(word)

vowels = "aeiou"

finally = ""

word.each_char do |letter|
    if vowels.include?(letter)
        finally += letter + "b" + letter 
    else  
        finally += letter 
    end 
end 

return finally

end


#######################################

def aba_array(words)

finally = []

finally = words.map {|word| aba_translate(word) }

return finally 

end