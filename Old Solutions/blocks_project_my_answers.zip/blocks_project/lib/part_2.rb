require "byebug"

def all_words_capitalized?(array_of_words)

return true if array_of_words.all? {|word| word.capitalize == word }

return false

end

def no_valid_url?(array_of_urls)

return true if array_of_urls.none? { |url| url.end_with?(".com", ".net", ".io", ".org") }

return false

end

def any_passing_students?(array_of_hashes)


return true if array_of_hashes.any? { |hash| average_grades(hash) >= 75 }

return false

end

def average_grades(hash)

    average_grade = 0

    grades_array = hash[:grades]

    average_grade = grades_array.inject { |sum, el| sum + el } / grades_array.size

    return average_grade 

end