class Board
    def initialize(n)
        @grid = Array.new(n) { |i| Array.new(n) {|i| :N}}
        @size = n * n
    end

    def size
        @size
    end 

    def [](array)
        @grid[array[0]][array[1]]
    end

    def []=(position_array, value)
        axis_1 = position_array[0]
        axis_2 = position_array[1]
        @grid[axis_1][axis_2] = value 
    end 

    def num_ships
        count = 0
        @grid.flatten.each do |values|
            if values == :S  
                count += 1
            end 
        end 
        return count
    end

    def attack(position_array)
  
        if self[position_array] == :S  
            self[position_array] = :H
            p "you sunk my battleship"
            return true
        else  
            self[position_array] = :X
            return false
        end
    end 

    def place_random_ships
        number_of_ships = @size * 0.25

        number_of_ships.to_i.times do 
            axis_1 = (0...@grid.length).to_a.sample.to_i
            axis_2 = (0...@grid.length).to_a.sample.to_i
            if @grid[axis_1][axis_2] != :S  
                @grid[axis_1][axis_2] = :S  
            else  
                redo
            end 
        end 
                
    end 

    def hidden_ships_grid
        hidden_grid = []

        @grid.each do |subArray|
            tempArray = []
            subArray.each do |ele|
                if ele == :S 
                    tempArray << :N  
                else  
                    tempArray << ele  
                end 
            end 
            hidden_grid << tempArray 
        end 
        

        return hidden_grid
    end 

    def self.print_grid(grid)
       grid.each do |subArray|
        puts subArray.join(" ")
       end
    end 

    def cheat
        Board.print_grid(@grid)
    end 

    def print 
        Board.print_grid(self.hidden_ships_grid)
    end
  
end
