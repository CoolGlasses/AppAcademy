require "byebug"

class Player

    def get_move
        p "enter a position with coordinates separated with a space like '4 7'"
        new_guess = []
        string = gets.chomp
        guess = string.split(" ")
        guess.each do |ele|
            new_guess << ele.to_i
        end

        return new_guess
    end


end
