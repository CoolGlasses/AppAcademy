def only_vowels?(string)

vowels = "aeiou"

string.each_char do |letter|
    if !vowels.include?(letter)
        return false
    end 
end

return true

end



p only_vowels?("aaoeee")  # => true
p only_vowels?("iou")     # => true
p only_vowels?("cat")     # => false
p only_vowels?("over")    # => false


