def union(*arrays)

finally = []

arrays.each do |array|
    array.each do |element|
        finally << element
    end 
end 

return finally

end

p union(["a", "b"], [1, 2, 3]) # => ["a", "b", 1, 2, 3]
p union(["x", "y"], [true, false], [20, 21, 23]) # => ["x", "y", true, false, 20, 21, 23]
