def coprime(num_1, num_2)

array1 = []
array2 = []

(1..num_1).each do |num1|
  if num_1 % num1 == 0
     array1 << num1 
  end 
end 

(1..num_2).each do |num2|
  if num_2 % num2 == 0
     array2 << num2 
  end 
end

array1.each do |num1|
  array2.each do |num2|
    if num1 == num2 && num1 != 1
       return false
    end
  end
end

return true
end



p coprime(25, 12)    # => true
p coprime(7, 11)     # => true
p coprime(30, 9)     # => false
p coprime(6, 24)     # => false
