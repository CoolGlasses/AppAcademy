def reverser(string, &prc)

reversed = []

array = string.split(" ")

array.each do |word|
    reversed << prc.call(word.reverse!)
end

return reversed.join(" ")

end

def word_changer(sentence, &prc)

finally = []

array = sentence.split(" ")

array.each do |word|
    finally << prc.call(word)
end 

return finally.join(" ")

end

def greater_proc_value(num, prc1, prc2)

if prc1.call(num) > prc2.call(num)
    return prc1.call(num)
else  
    return prc2.call(num)
end

end

def and_selector(array, prc1, prc2)

finally = []

array.each do |ele|
    if prc1.call(ele) && prc2.call(ele)
        finally << ele  
    end 
end 

return finally

end

def alternating_mapper(array, prc1, prc2)

finally = []

array.each_with_index do |ele, i|
    if i % 2 == 0
        finally << prc1.call(ele)
    else  
        finally << prc2.call(ele)
    end 
end 

return finally

end
