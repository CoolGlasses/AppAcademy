def my_map(array, &prc)

finally = []
array.each do |ele|
    finally << prc.call(ele)
end 

return finally 

end

def my_select(array, &prc)

finally = []
array.each do |ele|
    if prc.call(ele)
        finally << ele  
    end 
end 
    return finally

end

def my_count(array, &prc)

count = 0
array.each do |ele|
    if prc.call(ele)
        count += 1
    end 
end 

return count


end


def my_any?(array, &prc)

array.each do |ele|
    if prc.call(ele)
        return true
    end 
end 

return false

end


def my_all?(array, &prc)

    array.each do |ele|
        if !prc.call(ele)
            return false 
        end 
    end 

    return true
end 

def my_none?(array, &prc)

    array.each do |ele|
        if prc.call(ele)
            return false 
        end 
    end 

    return true

end