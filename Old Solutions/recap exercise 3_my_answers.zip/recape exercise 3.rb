require "byebug"

def no_dupes?(array)
    counter = {}
    counter = Hash.new{0}
    finally = []

    array.each do |ele|
        counter[ele] += 1
    end 

    counter.each do |k, v|
        if v == 1
            finally << k
        end 
    end 

    finally

end

def no_consecutive_repeats?(array)

    array.each_with_index do |ele1, i|
        array.each_with_index do |ele2, k|
            if k == i + 1 && ele1 == ele2 
                return false 
            end 
        end 
    end 

    return true


end


def char_indices(string)
    
    hash = Hash.new{[]}

    string.each_char.with_index do |char, i|
        hash[char] += [i]
    end 

    return hash

end

def longest_streak(string)

longest = ""
current = ""

(0...string.length).each do |i|
  if string[i] == string[i -1] || i == 0
     current += string[i]
  else 
     current = string[i]
  end  

  if current.length >= longest.length
     longest = current 
  end 

end

return longest

end

def bi_prime?(num)

factors = []

(2..num).each do |n|
  if num % n == 0
     factors << n  
  end 
end 

factors.each do |n|
  factors.each do |m|
    if is_prime?(n) && is_prime?(m) && n * m == num 
       return true 
    end 
  end 
end 

  return false

end

def is_prime?(num)

(2...num).each do |n|
  if num % n == 0
     return false 
  end 
end 

    return true

end

def vigenere_cipher(message, keys)

finally = ""

alphabet = "abcdefghijklmnopqrstuvwxyz"

array = []

k = 0

while k < message.length
  keys.each do |key|
    if message[k] != nil
    array << [message[k], key]
    k += 1
    end
  end 
end 

array.each do |subArray|

  shift = subArray[1] + alphabet.index(subArray[0])

  if shift > 26
     shift = shift % 26
  end 

  finally += (alphabet[shift])
end 

return finally

end

def vowel_rotate(string)

vowels = "aeiou"
finally = string

vowels_in_string = []
reversed = []

string.each_char.with_index do |letter, i|
  if vowels.include?(letter)
     vowels_in_string << [letter, i] 
     reversed << [letter, i] 
  end 
end

reversed.unshift(reversed.pop)

vowels_in_string.each_with_index do |subArray, i|

finally[subArray[1]] = reversed[i][0]
  
end 

return finally

end

class String 

  def select (&prc)

    finally = ""
 
    prc ||= Proc.new { return "" }

    self.each_char do |char|
        if prc.call(char)
           finally += char  
        end
    end 

    return finally
  end


  def map!(&prc)

      self.each_char.with_index do |ele, i|
        self[i] = prc.call(ele, i)
      end 
  
     self

  end
end

def multiply(a, b)

    return 0 if b == 0

    if b < 0
      -(a + multiply(a, (-b) - 1))
    else 
      (a + multiply(a, b - 1))
    end 
  
end  

def lucas_sequence(num)

  return [] if num == 0
  return [2, 1] if num == 2
  return [2] if num == 1

  finally = lucas_sequence(num - 1)
  next_ele = finally[-1] + finally[-2]
  finally << next_ele 
  return finally

end 

def prime_factorization(num)

  
  (2...num).each do |factor|
    if num % factor == 0
       next_factor = num / factor 
       return [ *prime_factorization(factor), *prime_factorization(next_factor)]
    end 
  end 

  return [num]

end  
