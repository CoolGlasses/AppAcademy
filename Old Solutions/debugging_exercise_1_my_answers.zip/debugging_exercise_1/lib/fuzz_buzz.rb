def fuzz_buzz(num)
    numbers = []

    (1..num).each do |i|
        if i % 3 != 0 && i % 5 != 0
            numbers << i
        end
    end

    numbers
end

