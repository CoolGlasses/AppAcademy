def partition(array, num)

finally = []
greater_than_or_equal = []
less_than = []

array.each do |ele|
    if ele >= num 
        greater_than_or_equal << ele  
    else  
        less_than << ele  
    end 
end 

finally << less_than 
finally << greater_than_or_equal

return finally 

end

def merge(hash_1, hash_2)
finally= {}
finally = Hash.new(0)

hash_1.each do |key1, val1|
    hash_2.each do |key2, val2|
        if key1 == key2 
            finally[key2] = val2 
        else  
            finally[key1] = val1 
            finally[key2] = val2 
        end 
    end 
end 

return finally

end


def censor(sentence, curses)

    vowels = "aeiou"

    array = sentence.split(" ")

    array.each do |word|
        if curses.include?(word.downcase)
            word.each_char do |letter|
                if vowels.include?(letter.downcase)
                    word[letter] = "*"
                end 
            end 
        end 
    end 

    return array.join(" ")

end


def power_of_two?(num)

    if Math.log2(num) % 1 == 0
        return true 
    else  
        return false 
    end 
    


end