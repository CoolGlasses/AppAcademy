def palindrome?(string)

    in_reverse = string 
    array = in_reverse.split("")
    finally = []

    i = array.length - 1
    while i >= 0
        finally << array[i]
        i -= 1
    end 

    if finally.join("") == string 
        return true
    else  
        return false 
    end 


end

def substrings(string)

finally = []

    string.each_char.with_index do |letter1, i|
        if i == 0
            finally << letter1
        else  
            finally << letter1
            finally << string[0..i]
        end  
        string.each_char.with_index do |letter2, k|
            if i < k && i !=0
                finally << string[i..k]
            end
        end 
    end

    return finally.sort

end

def palindrome_substrings(string)

    finally = []

    substring_array = substrings(string)

    substring_array.each do |ele|
        if palindrome?(ele) && ele.length > 1
            finally << ele
        end 
    end 


return finally   

end