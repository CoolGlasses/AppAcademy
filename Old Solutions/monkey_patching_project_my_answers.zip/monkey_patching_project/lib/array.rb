# Monkey-Patch Ruby's existing Array class to add your own custom methods

require "byebug"

class Array
    def span
        finally = 0
        if self == []
            return nil
        else
            finally = self.max - self.min
        end

        return finally 
    end 
  
    def average
        finally = 0.0

        if self == []
            return nil
        else  
            finally = self.sum.to_f / self.length
        end 
        
        return finally

    end 

    def median 
        finally = 0.0

        if self == []
            return nil
        end 

        sorted = self.sort
        idxs = sorted.length 
        

        if idxs % 2 != 0
            finally = sorted[((idxs + 1) / 2) - 1 ]
        else  
            finally = [sorted[(idxs / 2) - 1 ], sorted[(idxs / 2)]].average
        end  


        return finally 

    end 

    def counts
        counter = {}
        counter = Hash.new{0}

        self.each do |ele|
            counter[ele] += 1
        end 

        return counter
    end 


    def my_count(any)

        my_count = {}

        my_count = self.counts 
        
        return my_count[any]

    end

    def my_index(any)

        my_index = nil

        self.each_with_index do |ele, i|
            if any == ele  
                my_index = i
                break
            end 
        end 

        if my_index == nil
            return nil 
        else  
            return my_index 
        end 
        
    end

    def my_uniq
        finally = []
        hash = {}

        self.each_with_index do |ele, i|
            hash[ele] = i
        end
          
        hash.each_key do |key|
            finally << key
        end 

        return finally

    end 

    def my_transpose

        finally = []

        self.length.times do 
            finally << Array.new(self.length)
        end 

        flatten = self.flatten 
        elements_left = flatten.length - 1

         

            k = 0
            z = 0
            i = 0
            while i < self.length && z <= elements_left
                r = 0
                while r <= self.length - 1
                    finally[r][k] = flatten[z]  
                    z += 1
                    r += 1
                end 
                i += 1
                k += 1

            end 

        return finally 
    end








end


